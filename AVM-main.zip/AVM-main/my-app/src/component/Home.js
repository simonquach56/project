import React from "react";

import "./styles/bodyStyles.css";
import MenuBar from "./MenuBar";
const Home=()=> {
    return (
        <div> <MenuBar/>    
        <div class = "body">
       
        <h3> Home page.  </h3>
        <p>How to use this tool!</p>
        </div>
        </div>
        );
    }

    export default Home;